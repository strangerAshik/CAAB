<?php

class AircraftPrimary extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircrafts_primary';
}