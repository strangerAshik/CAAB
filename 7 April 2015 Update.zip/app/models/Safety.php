<?php

class Safety extends \Eloquent {
	protected $fillable = [];
}