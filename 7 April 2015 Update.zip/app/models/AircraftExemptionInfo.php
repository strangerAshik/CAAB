<?php

class AircraftExemptionInfo extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircraft_exemption_info';
}