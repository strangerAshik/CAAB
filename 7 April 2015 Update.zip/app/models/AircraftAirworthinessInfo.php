<?php

class AircraftAirworthinessInfo extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircraft_airworthiness_info';
}