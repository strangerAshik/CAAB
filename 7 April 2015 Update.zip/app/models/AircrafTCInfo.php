<?php

class AircrafTCInfo extends \Eloquent {
	protected $fillable = [];
	protected $table = 'aircraft_tc_info';
}